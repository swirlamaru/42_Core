/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_rev_int_tab.c                                    :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/26 10:46:01 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/28 13:52:11 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

void ft_rev_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	l;

	l = size - 1;
	i = 0;
	while (i < l)
	{
		temp = tab[i];
		tab[i] = tab[l];
		tab[l] = temp;
		i++;
		l--;
	}

}

#include <stdio.h>

int main(void) {

	int	tab[] = {1, 5, 8, 2, 3};
	int size = 5;

	ft_rev_int_tab(tab, size);

	for (int i = 0; i < size; i++)
		printf("%d ", tab[i]); 

}
