/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_sort_int_tab.c                                   :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@41.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2025/06/26 11:55:39 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/28 13:52:55 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	temp;

	i = 1;
	while (tab[i] && i < size)
	{
		if (tab[i] < tab[i - 1])
		{
			temp = tab[i];
			tab[i] = tab[i - 1];
			tab[i - 1] = temp;
			i = 0;
		}
		i++;
	}
}
