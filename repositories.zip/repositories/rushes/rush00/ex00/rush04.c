/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmathys <nmathys@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/27 19:05:24 by nmathys           #+#    #+#             */
/*   Updated: 2026/06/28 18:04:00 by nmathys          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	count_column(int x, char c1, char c2, char c3)
{
	int	column;

	column = 1;
	while (column <= x)
	{
		if (column == 1)
			ft_putchar(c1);
		else if (column == x)
			ft_putchar(c2);
		else
			ft_putchar(c3);
		column++;
	}
	ft_putchar('\n');
}

void	rush(int x, int y)
{
	int	line;

	if (x <= 0 || y <= 0)
		return ;
	line = 1;
	while (line <= y)
	{
		if (line == 1)
			count_column(x, 'A', 'C', 'B');
		else if (line == y)
			count_column(x, 'C', 'A', 'B');
		else
			count_column(x, 'B', 'B', ' ');
		line++;
	}
}
