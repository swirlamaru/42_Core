/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   rush04.c                                            :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/27 11:25:05 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/27 15:18:20 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	print_line(int x, int x_index)
{
	if (x_index == 1)
		ft_putchar(c1);
	else if(x_index == x)
		ft_putchar(c2);
	else
		ft_putchar(c3);
}

void	logic(int x, int x_index, int y, int y_index)
{
	if (y_index == 1) {
		if (x_index == 1)
			print_line(c1, c2, c3);
		else if(x_index == x)
			print_line(c2);
		else
			print_line(c3);
	}
	else if (y_index == y) {
		if (x_index == 1)
			print_line(c1);
		else if(x_index == x)
			print_line(c2);
		else
			print_line(c3);
	}
	else {
		if (x_index == 1)
			print_line(c1);
		else if(x_index == x)
			print_line(c2);
		else
			print_line(c3);
	}
}

void	rush(int x, int y)
{
	int	x_index;
	int	y_index;

	if (x <= 0 || y <= 0)
		return;
	y_index = 1;
	while (y_index <= y)
	{
		x_index = 1;
		while (x_index <= x)
		{
			logic(x, x_index, y, y_index);
			// if (y_index == 1)
			// 	print_line(x, x_index, 'A', 'C', 'B');
			// else if (y_index == y)
			// 	print_line(x, x_index, 'C', 'A', 'B');
			// else
			// 	print_line(x, x_index, 'B', 'B', ' ');
			x_index++;
		}
		ft_putchar('\n');
		y_index++;
	}
}

int	main(void) 
{
	rush(50, 5);
	return (0);
}
