/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_atoi.c                                           :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/06 15:31:09 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/06 15:31:18 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

int	char_with_whitespace(char c)
{
	return ((c <= '\r' && c >= '\t') || c == ' ');
}

int	ft_atoi(char *str)
{
	int	negative_count;
	int	i;
	int	keep;

	negative_count = 0;
	i = 0;
	keep = 0;
	while (str[i] && char_with_whitespace(str[i]))
		i++;
	while (str[i] == 43 || str[i] == 45)
	{
		if (str[i] == 45)
			negative_count++;
		i++;
	}
	while (str[i] >= 48 && str[i] <= 57)
	{
		keep = (keep * 10) + (str[i] - 48);
		i++;
	}
	if (negative_count % 2 != 0)
		return (-keep);
	return (keep);
}

/*#include <stdio.h>
int	main(void)
{
	char ascii[] = "    +-++-++++----+44d24445t5";
	printf("%d\n", ft_atoi(ascii));
	return (0);
}*/
