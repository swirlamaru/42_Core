/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_putnbr.c                                         :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/05 19:13:42 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/06 15:31:45 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

static void	ft_putnbr_recursive(long nb)
{
	char	c;

	if (nb >= 10)
		ft_putnbr_recursive(nb / 10);
	c = (char)('0' + (nb % 10));
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	long	lnb;

	lnb = nb;
	if (lnb == 0)
	{
		write(1, "0", 1);
		return ;
	}
	if (lnb < 0)
	{
		write(1, "-", 1);
		lnb = -lnb;
	}
	ft_putnbr_recursive(lnb);
}

/*int	main(void)
{
	int	nb = 12345;
	ft_putnbr(nb);
	return (0);
}*/
