/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_putnbr_base.c                                    :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/06 15:48:31 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/06 16:17:43 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_isalnum(char c)
{
	int	i;

	i = 0;
	if (!((c >= 65 && c <= 90)
			|| (c >= 97 && c <= 122)
			|| (c >= 48 && c <= 57)))
		return (0);
	return (1);
}

int	verify_base(char *base)
{
	int	i;
	int	j;
	int	len;

	i = 0;
	len = 0;
	while (base[len])
		len++;
	if (!base || len < 2)
		return (0);
	while (i < len)
	{
		if (base[i] == 45 || base[i] == 43 || !ft_isalnum(base[i]))
			return (0);
		j = i + 1;
		while (j < len)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (len);
}

void	print_in_base(long n, int len, char *base)
{
	if (n >= len)
		print_in_base(n / len, len, base);
	write(1, &base[n % len], 1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		baselen;
	long	n;

	baselen = verify_base(base);
	if (baselen == 0)
		return ;
	n = nbr;
	if (n < 0)
	{
		write(1, "-", 1);
		n = -n;
	}
	print_in_base(n, baselen, base);
}

/*int	main(void)
{
	int nbr = 14;
	char base[] = "01";
	ft_putnbr_base(nbr, base);
	return (0);
}*/
