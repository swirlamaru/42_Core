/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strlcat.c                                        :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/02 14:34:38 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/02 15:48:40 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	slen;
	unsigned int	dlen;

	i = 0;
	slen = ft_strlen(src);
	dlen = ft_strlen(dest);
	if (size == 0)
		return (slen);
	if (size <= dlen)
		return (size + slen);
	while (src[i] && (dlen + i) < size - 1)
	{
		dest[dlen + i] = src[i];
		i++;
	}
	dest[dlen + i] = '\0';
	return (dlen + slen);
}
/*
#include <stdio.h>
int main(void)
{
	char dest1[20] = "Hello";
	char dest2[5] = "Hi";
	char dest3[10] = "";

	unsigned int t1 = ft_strlcat(dest1, "World", 20);
	unsigned int t2 = ft_strlcat(dest2, "!", 5);
	unsigned int t3 = ft_strlcat(dest3, "ABC", 10);

	printf("test 1 = %u, expected: HelloWorld got =%s\n", t1, dest1);
	printf("test 2 = %u expected: Hi! got =%s\n", t2, dest2);
	printf("test 3 = %u expected: ABC got =%s\n", t3, dest3);

	return (0);
}*/
