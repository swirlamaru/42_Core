/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strcmp.c                                         :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/01 10:51:39 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/01 11:51:59 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] && s2[i] && s1[i] == s2[i])
		i++;
	return (s1[i] - s2[i]);
}

/*#include <stdio.h>
int	main(void)
{
	char s1[] = "Hello";
	char s2[] = "Hel";
	int result;
	result = ft_strcmp(s1, s2);

	printf("expected result : 2 ; got => %d\n", result);
}*/
