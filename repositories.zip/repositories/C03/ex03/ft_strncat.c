/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strncat.c                                        :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/01 19:10:22 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/02 14:50:37 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	int				dlen;
	char			*start;

	i = 0;
	dlen = ft_strlen(dest);
	start = dest;
	while (src[i] && i < nb)
	{
		dest[dlen + i] = src[i];
		i++;
	}
	dest[dlen + i] = '\0';
	return (start);
}

/*#include <unistd.h>
int	main(void)
{
	char dest[10] = "ss";
	char src[] = "AAAAA";
	unsigned int size = 3;

	char *result = ft_strncat(dest, src, size);

	for (int i = 0; result[i]; i++) {
		write(1, &result[i], 1);
	}
	write(1, "\n", 1);
}*/
