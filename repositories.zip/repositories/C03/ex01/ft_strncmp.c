/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strncmp.c                                        :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/01 11:05:08 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/01 11:49:17 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && s1[i] && s2[i] && s1[i] == s2[i])
		i++;
	if (i == n || s1[i] == s2[i])
		return (0);
	return (s1[i] - s2[i]);
}

/*#include <stdio.h>
int	main(void)
{
	char s1[] = "Hello";
	char s2[] = "Hel";
	unsigned int size = 3;
	int result;
	result = ft_strncmp(s1, s2, size);

	printf("expected result : 0 ; got => %d\n", result);
}*/
