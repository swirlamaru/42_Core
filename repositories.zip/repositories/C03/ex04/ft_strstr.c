/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strstr.c                                         :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/07/02 02:19:33 by sspirig        #+#    #+#                */
/*   Updated: 2026/07/02 15:05:07 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	if (!*to_find)
		return (str);
	while (str[i])
	{
		j = 0;
		while (str[i + j] == to_find[j]
			&& str[i + j] && to_find[j])
			j++;
		if (to_find[j] == '\0')
			return (&str[i]);
		i++;
	}
	return (0);
}

/*s#include <stdio.h>

int main(void)
{
	char *haystack = "hello world";
	char *needle = "world";
	printf("haystack = \"hello worldsssss\" expecting: \"world\" got: %s\n", ft_strstr(haystack, needle));
		return 0;
}*/
