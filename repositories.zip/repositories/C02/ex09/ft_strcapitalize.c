/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strcapitalize.c                                  :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/29 18:56:57 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/30 00:26:14 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if ((str[i] >= 65) && (str[i] <= 90))
			str[i] += 32;
		i++;
	}
	i = 0;
	while (str[i])
	{
		if (i == 0 || !((str[i - 1] >= 65 && str[i - 1] <= 90)
				|| (str[i - 1] >= 97 && str[i - 1] <= 122)
				|| (str[i - 1] >= 48 && str[i - 1] <= 57)))
			if ((str[i] >= 65 && str[i] <= 90)
				|| (str[i] >= 97 && str[i] <= 122))
				str[i] -= 32;
		i++;
	}
	return (str);
}

/*#include <stdio.h>

int main(void)
{
	char s[] = "hi, how are you? 42words forty-two; fifty+and+one";
	printf("%s\n", ft_strcapitalize(s));
	return 0;
}*/
