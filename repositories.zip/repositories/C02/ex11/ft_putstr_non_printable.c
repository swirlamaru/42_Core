/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_putstr_non_printable.c                           :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/30 12:31:10 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/30 13:34:58 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	convert_print_hex(unsigned char c)
{
	static char	*lookup = "0123456789abcdef";
	char		high;
	char		low;

	high = lookup[c >> 4];
	low = lookup[c & 0x0F];
	write(1, &high, 1);
	write(1, &low, 1);
}

void	ft_putstr_non_printable(char *str)
{
	int				i;
	unsigned char	c;

	i = 0;
	while (str[i])
	{
		c = (unsigned char)str[i];
		if (c >= 32 && c <= 126)
		{
			write(1, &c, 1);
		}
		else
		{
			write(1, "\\", 1);
			convert_print_hex(c);
		}
		i++;
	}
}

/*#include <stdio.h>

int	main(void)
{
	char str[] = "Hello\nHow are you?";

	ft_putstr_non_printable(str);

	printf("%s\n", str);
}*/
