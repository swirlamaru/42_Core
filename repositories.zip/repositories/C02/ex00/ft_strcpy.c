/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_strcpy.c                                         :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/28 16:31:36 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/29 16:39:51 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
/*#include <stdio.h>

int	main(void)
{
	char dest[100];
	char src[] = "copy this";

	char *dest_ptr = ft_strcpy(dest, src);
	
	printf("     src: %s\n", src);
	printf("    dest: %s\n", dest);
	printf("dest_ptr: %s\n", dest_ptr);
	printf("    dest: %p\n", dest);
	printf("dest_ptr: %p\n", dest);
	
	printf("dest => %s\nsrc => %s", dest, src);
	return (0);
}*/
