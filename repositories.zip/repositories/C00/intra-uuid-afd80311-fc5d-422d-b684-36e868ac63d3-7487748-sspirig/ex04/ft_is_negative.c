/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_is_negative.c                                    :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/25 11:42:13 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/25 11:54:02 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	answer;

	if (n < 0)
	{
		answer = 'N';
		write(1, &answer, 1);
	}
	else
	{
		answer = 'P';
		write(1, &answer, 1);
	}
}

/*int	main(void)
{
	ft_is_negative(-1);
}*/
