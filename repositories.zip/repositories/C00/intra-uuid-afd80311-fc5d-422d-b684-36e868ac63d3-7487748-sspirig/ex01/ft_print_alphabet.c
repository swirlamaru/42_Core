/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_print_alphabet.c                                 :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/24 19:01:43 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/24 23:54:40 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(void)
{
	int	ascii;

	ascii = 97;
	while (ascii <= 122)
	{
		write(1, &ascii, 1);
		ascii += 1;
	}
}

/*int	main(void)
{
	ft_print_alphabet();
	return (0);
}*/
