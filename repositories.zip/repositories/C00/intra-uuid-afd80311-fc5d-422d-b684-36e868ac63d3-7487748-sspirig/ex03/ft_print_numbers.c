/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_print_numbers.c                                  :+:    :+:           */
/*                                                      +:+                   */
/*   By: sspirig <marvin@42.fr>                        +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/25 11:31:09 by sspirig        #+#    #+#                */
/*   Updated: 2026/06/25 13:53:00 by sspirig        ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_numbers(void)
{
	int	number;

	number = 48;
	while (number <= 57)
	{
		write(1, &number, 1);
		number += 1;
	}
}

/*int	main(void)
{
	ft_print_numbers();
	return (0);
}*/
