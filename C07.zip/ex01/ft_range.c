/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sspirig <sspirig@student.42lausanne.ch>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/14 20:06:19 by sspirig           #+#    #+#             */
/*   Updated: 2026/07/15 22:04:24 by sspirig          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	value;
	int	i;
	int	*tab;
	int	*start;

	if (min >= max)
		return (NULL);
	value = min;
	tab = malloc(sizeof(int) * (max - min));
	if (!tab)
		return (NULL);
	start = tab;
	i = 0;
	while (value < max)
	{
		tab[i] = value;
		value++;
		i++;
	}
	return (start);
}

/*#include <stdio.h>
int	main(void)
{
	int	min = -247;
	int	max = 505;
	int	*tab = ft_range(min, max);
	int size = max - min;
	for (int i = 0; i < size; i++)
	{
		printf("tab[%d] => %d\n", i, tab[i]);
	}
	free(tab);
	return (0);
}*/
