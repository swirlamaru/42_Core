/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sspirig <sspirig@student.42lausanne.ch>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/10 02:27:09 by sspirig           #+#    #+#             */
/*   Updated: 2026/07/16 13:03:02 by sspirig          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int	len;
	char	*dup;
	char	*ptr;

	if (!src)
		return (NULL);
	len = 0;
	while (src[len])
		len++;
	dup = malloc(sizeof(char) * len + 1);
	if (dup == NULL)
		return (NULL);
	ptr = dup;
	while (*src)
	{
		*dup = *src;
		src++;
		dup++;
	}
	*dup = '\0';
	return (ptr);
}

/*#include <stdio.h>

int	main(void)
{
	char	str[] = "tongrandpere";
	char	*dup = ft_strdup(str);
	printf("str[] => %s | dup[] => %s", str, dup);
	return (0);
}*/
