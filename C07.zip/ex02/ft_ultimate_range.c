/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sspirig <sspirig@student.42lausanne.ch>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/14 22:04:48 by sspirig           #+#    #+#             */
/*   Updated: 2026/07/16 13:04:28 by sspirig          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	value;
	int	i;
	int	*tab;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	value = min;
	tab = malloc(sizeof(int) * (max - min));
	if (!tab)
		return (-1);
	*range = tab;
	i = 0;
	while (value < max)
	{
		tab[i] = value;
		value++;
		i++;
	}
	return (i);
}

/*#include <stdio.h>
int	main(void)
{
	int	min = 45;
	int	max = 24;
	int	*tab = NULL;
	int	size = ft_ultimate_range(&tab, min, max);

	if (size == -1)
	{
		printf("error memory allocation\n");
		return (1);
	}
	if (size == 0)
	{
		printf("error (min >= max) result => %d\n", size);
		return (1);
	}
	for (int i = 0; i < size; i++)
	{
		printf("tab[%d] => %d\n", i, tab[i]);
	}

	free(tab);
	return (0);
}*/
