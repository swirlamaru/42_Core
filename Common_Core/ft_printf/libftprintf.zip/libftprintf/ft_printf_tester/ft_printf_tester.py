#!/usr/bin/env python3
import os
import subprocess
import sys
import tempfile
from pathlib import Path

COLOR_SUCCESS = "\033[32m"
COLOR_FAILURE = "\033[31m"
COLOR_INFO = "\033[36m"
COLOR_RESET = "\033[0m"
COLOR_CYAN = "\033[1;36m"
COLOR_YELLOW = "\033[1;33m"

# ==============================================================================
# MANDATORY TESTS RUNNER
# ==============================================================================

C_MANDATORY_RUNNER_TEMPLATE = r"""
# include <stdarg.h>
# include <unistd.h>
# include <stdio.h>

int	ft_printf(const char *format, ...);

int	ft_print_char(int c);
int	ft_print_string(char *str);
int	ft_print_decimal(int n);
int	ft_print_unsigned(unsigned int n);
int	ft_print_hex(unsigned long nb, const char form);
int	ft_print_pointer(unsigned long pointer);
int	ft_print_percent(void);

int main()
{
    int printf_bytes, ft_printf_bytes;
    int count;

	setvbuf(stdout, NULL, _IONBF, 0);
    // *************************************************************
    // **               Character (c) Tests                     **
    // *************************************************************

    count = 0;
    printf("\033[1;33m************************\033[0m character \033[1;33m************************ \033[0m\n");

    // Test 1: Basic character
    char ch = 'A';
    printf_bytes = printf("|%c|\n", ch);
    ft_printf_bytes = ft_printf("|%c|\n", ch);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               String (s) Tests                        **
    // *************************************************************

    printf("\033[1;33m************************\033[0m string \033[1;33m************************ \033[0m\n");

    // Test 1: String w
    char *str = "Hello testing";
    printf_bytes = printf("|%s|\n", str);
    ft_printf_bytes = ft_printf("|%s|\n", str);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");


    // *************************************************************
    // **               Pointer (p) Tests                       **
    // *************************************************************

    printf("\033[1;33m************************\033[0m pointer \033[1;33m************************ \033[0m\n");

    // Test 1: NULL pointer
    void *ptr = NULL;
    printf_bytes = printf("|%p|\n", ptr);
    ft_printf_bytes = ft_printf("|%p|\n", ptr);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               Decimal (d) / Integer (i) Tests          **
    // *************************************************************

    printf("\033[1;33m************************\033[0m decimal \033[1;33m************************ \033[0m\n");

    // Test 1: Decimal positive number
    printf_bytes = printf("|%d|\n", 42);
    ft_printf_bytes = ft_printf("|%d|\n", 42);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");
    printf("\n");

    // Test 2: Decimal negative number
    printf_bytes = printf("|%d|\n", -42);
    ft_printf_bytes = ft_printf("|%d|\n", -42);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               Unsigned (u) Tests                      **
    // *************************************************************

    printf("\033[1;33m************************\033[0m unsigned \033[1;33m************************ \033[0m\n");

    // Test 1: Unsigned value
    unsigned int u_val = 4294967295;
    printf_bytes = printf("|%u|\n", u_val);
    ft_printf_bytes = ft_printf("|%u|\n", u_val);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");
    printf("\n");

    // Test 2: Unsigned zero
    printf_bytes = printf("|%u|\n", 0);
    ft_printf_bytes = ft_printf("|%u|\n", 0);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               Hexadecimal (x) Tests                   **
    // *************************************************************

    printf("\033[1;33m************************\033[0m hex(lower) \033[1;33m************************ \033[0m\n");

    // Test 1: Hexadecimal (lowercase)
    printf_bytes = printf("|%x|\n", 255);
    ft_printf_bytes = ft_printf("|%x|\n", 255);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               Hexadecimal (X) Tests                   **
    // *************************************************************
    printf("\033[1;33m************************\033[0m hex (Upper) \033[1;33m************************ \033[0m\n");

    // Test 1: Hexadecimal (uppercase)
    printf_bytes = printf("|%X|\n", 255);
    ft_printf_bytes = ft_printf("|%X|\n", 255);
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    // *************************************************************
    // **               Percent (%) Tests                       **
    // *************************************************************

    printf("\033[1;33m************************\033[0m percent sign \033[1;33m************************ \033[0m\n");

    // Test 1: Percent sign
    printf_bytes = printf("|%%|\n");
    ft_printf_bytes = ft_printf("|%%|\n");
    printf("Bytes printed by or_printf: %d\n", printf_bytes);
    printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
    if (printf_bytes == ft_printf_bytes)
    {
        printf("\033[32m ************* OK *************  \033[0m\n");
        count++;
    }
    else
        printf("\033[31m ************* NO *************  \033[0m\n");

    if (count == 10)
    {   
        printf("\n\033[35m********************************************* \033[0m\n");
        printf("\033[32m******** All tests output and bytes OK! *******  \033[0m\n");   
        printf("\033[35m***********************************************  \033[0m\n");
    }
    else
    {   
        printf("\n\033[35m************************************  \033[0m\n");
        printf("\033[31m*********** ERRORS FOUND ***********  \033[0m\n");   
        printf("\033[35m************************************  \033[0m\n");
    }


    return 0;
}
"""

# ==============================================================================
# BONUS TESTS RUNNER
# ==============================================================================

C_BONUS_RUNNER_TEMPLATE = r"""

#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>

typedef struct s_format
{
	int		is_left_justified;
	int		is_there_zero;
	int		is_there_plus;
	int		is_there_space;
	int		is_there_cardinal;
	int		width_value;
	int		precision_value;
	char	specifier;
}			t_format;

// function prototypes
int			ft_printf(const char *format, ...);
int			which_specifier(char specifier, va_list args, t_format *fmt);
int			ft_isdigit(int c);
int			ft_atoi(const char *nptr);
void		ft_putnbr_write(int n, char *buffer);
int			handle_null_size(t_format *fmt);
int			handle_null(t_format *fmt);
int			width_string(char *str, t_format *fmt);
int			string_size(char *str);
int			width_size_number_u(unsigned long long n, t_format *fmt);
int			width_calculator_u(unsigned long long n, t_format *fmt);
int			ft_print_unsigned(unsigned long long n, t_format *fmt);
int			string_printer(char *str, t_format *fmt);
int			string_printer_sizer(char *str, t_format *fmt);
int			ft_print_string(char *str, t_format *fmt);
int			ft_print_hex_pointer(unsigned long nb, const char specifier,
				t_format *fmt);
int			ft_print_pointer(unsigned long pointer, t_format *fmt);
int			ft_hex_prefix(t_format *fmt, const char specifier,
				unsigned long nb);
int			ft_print_hex(unsigned long nb, const char specifier, t_format *fmt);
int			ft_print_decimal(int n, t_format *fmt);
int			ft_print_char(int c, t_format *fmt);
int			width_single_char(t_format *fmt);
int			populate_nil(t_format *fmt);
int			width_calculator_nil(int index, t_format *fmt);
int			width_calculator_pointer(int index, t_format *fmt);
int			width_size_number_pointer(int index, t_format *fmt);
int			handle_padding_pointer(int padding_length, char padding_char);
void		reset_format(t_format *fmt);
int			parse_flags_and_width(const char *format, int i, t_format *fmt);
int			parse_precision_and_specifier(const char *format, int i,
				t_format *fmt);
int			parse_format(const char *format, int i, t_format *fmt);
int			ft_hex_logic(unsigned long nb, const char specifier, char *buffer,
				t_format *fmt);
int			print_buffer_reverse(char *buffer, int index);
char		*which_base(const char specifier);
int			width_calculator_x(int index, t_format *fmt);
int			width_size_number_x(int index, t_format *fmt);
int			handle_padding_x(int padding_length, char padding_char,
				t_format *fmt);
int			precision_size_report_x(int n, t_format *fmt);
int			precision_calculator_x(int n, t_format *fmt);
int			width_size_number(int n, t_format *fmt);
int			handle_padding(int padding_length, char padding_char);
int			width_calculator(int n, t_format *fmt);
int			number_size_calculator_decimal(int n);
int			sign_checker(int n, t_format *fmt);
int			buffer_number_printer(int n, t_format *fmt);
int			precision_calculator(int n, t_format *fmt);
int			precision_size_report(int n, t_format *fmt);
int			buffer_number_printer_unsigned(unsigned long long n, t_format *fmt);
void		ft_putnbr_write_unsigned(unsigned long long n, char *buffer);
int			number_size_calculator_unsigned(unsigned long long n);
int			precision_calculator_unsigned(unsigned long long n, t_format *fmt);
int			precision_size_report_unsigned(unsigned long long n, t_format *fmt);

/*
	place before return in printf to debug flags
			printf("\n****is_left_justified: %d\n", fmt.is_left_justified);
			printf("****is_there_zero: %d\n", fmt.is_there_zero);
			printf("****is_there_plus: %d\n", fmt.is_there_plus);
			printf("****is_there_space: %d\n", fmt.is_there_space);
			printf("****is_there_cardinal: %d\n", fmt.is_there_cardinal);
			printf("****width_value: %d\n", fmt.width_value);
			printf("****precision_value: %d\n", fmt.precision_value);
			printf("****specifier: %c\n", fmt.specifier);
*/

int	main(void)
{
	char	ch;
	char	ch1;
	char	ch2;
	char	ch3;
	char	ch4;
	char	ch5;
	char	ch6;
	char	ch7;
	char	ch8;
	char	ch9;
	char	ch10;
	void	*null_ptr_2;
	void	*null_ptr_3;
	void	*ptr_7;
	void	*ptr_8;
	void	*ptr_9;
	void	*ptr_10;
	void	*ptr_11;
	void	*ptr_12;
	void	*ptr_13;
	void	*ptr_14;
	void	*ptr_15;
	void	*ptr_16;
	char	*str;
	char	*empty_str;
	char	*null_str;

	setvbuf(stdout, NULL, _IONBF, 0);

	int printf_bytes, ft_printf_bytes;
    int count = 0;
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m **************** \033[0m           decimal              \033[1;33m      ******************* \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	// Test 0: Test with width and zero padding, positive number
	printf_bytes = printf("Hello World |%+05d|teste\n", 1);
	ft_printf_bytes = ft_printf("Hello World |%+05d|teste\n", 1);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 1: Test with width and zero padding, positive number
	printf_bytes = printf("Test 1: |%05d|\n", 42);
	ft_printf_bytes = ft_printf("Test 1: |%05d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 2: Test with width and zero padding, negative number
	printf_bytes = printf("Test 2: |%05d|\n", -42);
	ft_printf_bytes = ft_printf("Test 2: |%05d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 3: Test with precision and no width
	printf_bytes = printf("Test 3: |%.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 3: |%.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 4: Test with precision and width, no zero padding
	printf_bytes = printf("Test 4: |%10.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 4: |%10.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 7: Test with width and positive sign
	printf_bytes = printf("Test 7: |%+5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 7: |%+5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 8: Test with width, zero padding, and positive sign
	printf_bytes = printf("Test 8: |%+05d|\n", 42);
	ft_printf_bytes = ft_printf("Test 8: |%+05d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 9: Test with precision, width, and positive sign
	printf_bytes = printf("Test 9: |%+10.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 9: |%+10.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 10: Test with space flag, positive number
	printf_bytes = printf("Test 10: |% 5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 10: |% 5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 11: Test with space flag, negative number
	printf_bytes = printf("Test 11: |% 5d|\n", -42);
	ft_printf_bytes = ft_printf("Test 11: |% 5d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 12: Test with space flag and zero padding
	printf_bytes = printf("Test 12: |% 05d|\n", 42);
	ft_printf_bytes = ft_printf("Test 12: |% 05d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 13: Test with left justification and width
	printf_bytes = printf("Test 13: |%-5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 13: |%-5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 14: Test with left justification, width, and precision
	printf_bytes = printf("Test 14: |%-10.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 14: |%-10.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 15: Test with left justification, width, and negative number
	printf_bytes = printf("Test 15: |%-10d|\n", -42);
	ft_printf_bytes = ft_printf("Test 15: |%-10d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 16: Test with zero padding and width larger than number
	printf_bytes = printf("Test 16: |%010d|\n", 1234);
	ft_printf_bytes = ft_printf("Test 16: |%010d|\n", 1234);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 18: Test with zero padding and precision only
	printf_bytes = printf("Test 18: |%.5d|\n", 1234);
	ft_printf_bytes = ft_printf("Test 18: |%.5d|\n", 1234);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 19: Test with width smaller than number, no flags
	printf_bytes = printf("Test 19: |%2d|\n", 12345);
	ft_printf_bytes = ft_printf("Test 19: |%2d|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 20: Test with precision smaller than number
	printf_bytes = printf("Test 20: |%.3d|\n", 12345);
	ft_printf_bytes = ft_printf("Test 20: |%.3d|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 21: Test with precision equal to number size
	printf_bytes = printf("Test 21: |%.5d|\n", 12345);
	ft_printf_bytes = ft_printf("Test 21: |%.5d|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 22: Test with width and precision larger than number
	printf_bytes = printf("Test 22: |%10.8d|\n", 123);
	ft_printf_bytes = ft_printf("Test 22: |%10.8d|\n", 123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 23: Test with width and precision equal to each other
	printf_bytes = printf("Test 23: |%8.8d|\n", 123);
	ft_printf_bytes = ft_printf("Test 23: |%8.8d|\n", 123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 24: Test with negative number, width, and precision
	printf_bytes = printf("Test 24: |%10.5d|\n", -123);
	ft_printf_bytes = ft_printf("Test 24: |%10.5d|\n", -123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 25: Test with zero padding, width, and negative number
	printf_bytes = printf("Test 25: |%010d|\n", -123);
	ft_printf_bytes = ft_printf("Test 25: |%010d|\n", -123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 27: Test with space flag and negative number
	printf_bytes = printf("Test 27: |% 10d|\n", -123);
	ft_printf_bytes = ft_printf("Test 27: |% 10d|\n", -123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 29: Test with width and zero padding, positive number
	printf_bytes = printf("Test 29: |%05d|\n", 42);
	ft_printf_bytes = ft_printf("Test 29: |%05d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 30: Test with width and zero padding, negative number
	printf_bytes = printf("Test 30: |%05d|\n", -42);
	ft_printf_bytes = ft_printf("Test 30: |%05d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 31: Test with width, no padding, positive number
	printf_bytes = printf("Test 31: |%5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 31: |%5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 32: Test with width, no padding, negative number
	printf_bytes = printf("Test 32: |%5d|\n", -42);
	ft_printf_bytes = ft_printf("Test 32: |%5d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 33: Test with precision, positive number
	printf_bytes = printf("Test 33: |%.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 33: |%.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 34: Test with precision, negative number
	printf_bytes = printf("Test 34: |%.5d|\n", -42);
	ft_printf_bytes = ft_printf("Test 34: |%.5d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 35: Test with precision and width, positive number
	printf_bytes = printf("Test 35: |%8.5d|\n", 42);
	ft_printf_bytes = ft_printf("Test 35: |%8.5d|\n", 42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 36: Test with precision and width, negative number
	printf_bytes = printf("Test 36: |%8.5d|\n", -42);
	ft_printf_bytes = ft_printf("Test 36: |%8.5d|\n", -42);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 37: Test with width smaller than number of digits, positive number
	printf_bytes = printf("Test 37: |%2d|\n", 12345);
	ft_printf_bytes = ft_printf("Test 37: |%2d|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 38: Test with width smaller than number of digits, negative number
	printf_bytes = printf("Test 38: |%2d|\n", -12345);
	ft_printf_bytes = ft_printf("Test 38: |%2d|\n", -12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 41: Test with width, precision zero, and zero number
	printf_bytes = printf("Test 41: |%5.0d|\n", 0);
	ft_printf_bytes = ft_printf("Test 41: |%5.0d|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 42: Test with width and precision, number zero
	printf_bytes = printf("Test 42: |%5.3d|\n", 0);
	ft_printf_bytes = ft_printf("Test 42: |%5.3d|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 43: Test negative number with large width and precision
	printf_bytes = printf("Test 43: |%15.10d|\n", -123);
	ft_printf_bytes = ft_printf("Test 43: |%15.10d|\n", -123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 44: Test positive number with large width and precision
	printf_bytes = printf("Test 44: |%15.10d|\n", 123);
	ft_printf_bytes = ft_printf("Test 44: |%15.10d|\n", 123);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 45: Test number zero with no width and precision zero
	printf_bytes = printf("Test 45: |%.0d|\n", 0);
	ft_printf_bytes = ft_printf("Test 45: |%.0d|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	///////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m **************** \033[0m           percent               \033[1;33m      ****************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	printf_bytes = printf("|%%|\n");
	ft_printf_bytes = ft_printf("|%%|\n");
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	///////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m ************** \033[0m           single char               \033[1;33m      **************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	ch = 'A';
	printf_bytes = printf("|%11c|\n", ch);
	ft_printf_bytes = ft_printf("|%11c|\n", ch);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Basic Case: Single character without width
	ch1 = 'B';
	printf_bytes = printf("|%c|\n", ch1);
	ft_printf_bytes = ft_printf("|%c|\n", ch1);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Basic Case: Single character with width
	ch2 = 'C';
	printf_bytes = printf("|%5c|\n", ch2);
	ft_printf_bytes = ft_printf("|%5c|\n", ch2);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Basic Case: Single character with left justification
	ch3 = 'D';
	printf_bytes = printf("|%-5c|\n", ch3);
	ft_printf_bytes = ft_printf("|%-5c|\n", ch3);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Null character
	ch4 = '\0';
	printf_bytes = printf("n1|%c|\n", ch4);
	ft_printf_bytes = ft_printf("n1|%c|\n", ch4);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Null character with width
	ch5 = '\0';
	printf_bytes = printf("n2|%5c|\n", ch5);
	ft_printf_bytes = ft_printf("n2|%5c|\n", ch5);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Null character with left justification
	ch6 = '\0';
	printf_bytes = printf("n3|%-5c|\n", ch6);
	ft_printf_bytes = ft_printf("n3|%-5c|\n", ch6);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width smaller than character output
	ch7 = 'E';
	printf_bytes = printf("|%1c|\n", ch7);
	ft_printf_bytes = ft_printf("|%1c|\n", ch7);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Negative width (interpreted as left justification)
	ch8 = 'F';
	printf_bytes = printf("|%-5c|\n", ch8);
	ft_printf_bytes = ft_printf("|%-5c|\n", ch8);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Large width
	ch9 = 'G';
	printf_bytes = printf("|%50c|\n", ch9);
	ft_printf_bytes = ft_printf("|%50c|\n", ch9);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width and zero padding (ignored for `%c`)
	ch10 = 'H';
	printf_bytes = printf("|%5c|\n", ch10);
	ft_printf_bytes = ft_printf("|%5c|\n", ch10);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Non-ASCII character
	char ch11 = 0xE9; // é in extended ASCII
	printf_bytes = printf("|%c|\n", ch11);
	ft_printf_bytes = ft_printf("|%c|\n", ch11);
	printf("Bytes nr: %d\n", printf_bytes);
	printf("Bytes FT: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m **************** \033[0m           pointers              \033[1;33m      ****************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	// Edge Case 8: NULL pointer with width
	null_ptr_2 = NULL;
	printf_bytes = printf("|%20p|\n", null_ptr_2);
	ft_printf_bytes = ft_printf("|%20p|\n", null_ptr_2);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 9: NULL pointer with left justification and width
	null_ptr_3 = NULL;
	printf_bytes = printf("|%-25p|\n", null_ptr_3);
	ft_printf_bytes = ft_printf("|%-25p|\n", null_ptr_3);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 10: Pointer with small width (smaller than pointer size)
	ptr_7 = (void *)0xDEADBEEF;
	printf_bytes = printf("|%5p|\n", ptr_7);
	ft_printf_bytes = ft_printf("|%5p|\n", ptr_7);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 11: Pointer with very large width
	ptr_8 = (void *)0xBEEFDEAD;
	printf_bytes = printf("|%50p|\n", ptr_8);
	ft_printf_bytes = ft_printf("|%50p|\n", ptr_8);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 12: Pointer with zero width and zero padding
	ptr_9 = (void *)123456789;
	printf_bytes = printf("|%10p|\n", ptr_9);
	ft_printf_bytes = ft_printf("|%10p|\n", ptr_9);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 13: Pointer with left justification, zero padding ignored
	ptr_10 = (void *)789456;
	printf_bytes = printf("|%-15p|\n", ptr_10);
	ft_printf_bytes = ft_printf("|%-15p|\n", ptr_10);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 14: Pointer to maximum unsigned value
	ptr_11 = (void *)0xFFFFFFFFFFFFFFFF;
	printf_bytes = printf("|%p|\n", ptr_11);
	ft_printf_bytes = ft_printf("|%p|\n", ptr_11);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 15: Pointer to address zero
	ptr_12 = (void *)0;
	printf_bytes = printf("|%p|\n", ptr_12);
	ft_printf_bytes = ft_printf("|%p|\n", ptr_12);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 16: Pointer with multiple conflicting flags
	ptr_13 = (void *)0xCAFEBABE;
	printf_bytes = printf("|%-20p|\n", ptr_13);
	ft_printf_bytes = ft_printf("|%-20p|\n", ptr_13);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 17: Large address with left justification
	ptr_14 = (void *)0x7FFFFFFFFFFFFFFF;
	printf_bytes = printf("|%-40p|\n", ptr_14);
	ft_printf_bytes = ft_printf("|%-40p|\n", ptr_14);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 18: Pointer to small address
	ptr_15 = (void *)0x1;
	printf_bytes = printf("|%p|\n", ptr_15);
	ft_printf_bytes = ft_printf("|%p|\n", ptr_15);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case 19: Pointer with mixed zero padding and width
	ptr_16 = (void *)0xABCDEF;
	printf_bytes = printf("|%15p|\n", ptr_16);
	ft_printf_bytes = ft_printf("|%15p|\n", ptr_16);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m *************** \033[0m           hex values               \033[1;33m      **************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	// Edge Case: Precision greater than the number of digits
	printf_bytes = printf("|%.10x|\n", 45);
	ft_printf_bytes = ft_printf("|%.10x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Precision of 0 with value 0
	printf_bytes = printf("|%.0x|\n", 0);
	ft_printf_bytes = ft_printf("|%.0x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width with zero padding
	printf_bytes = printf("|%05x|\n", 45);
	ft_printf_bytes = ft_printf("|%05x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width with left justification
	printf_bytes = printf("|%-5x|\n", 45);
	ft_printf_bytes = ft_printf("|%-5x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Combination of width, left justification, and precision
	printf_bytes = printf("|%-8.5x|\n", 45);
	ft_printf_bytes = ft_printf("|%-8.5x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Zero value with width, precision, and #
	printf_bytes = printf("|%#8.0x|\n", 0);
	ft_printf_bytes = ft_printf("|%#8.0x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Zero value with width, precision, and left justification
	printf_bytes = printf("|%-#8.0x|\n", 0);
	ft_printf_bytes = ft_printf("|%-#8.0x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Maximum unsigned int
	printf_bytes = printf("|%#x|\n", 4294967295U);
	ft_printf_bytes = ft_printf("|%#x|\n", 4294967295U);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Minimum non-zero value (1)
	printf_bytes = printf("|%#x|\n", 1);
	ft_printf_bytes = ft_printf("|%#x|\n", 1);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Large number with all flags
	printf_bytes = printf("|%-#20.15x|\n", 123456789);
	ft_printf_bytes = ft_printf("|%-#20.15x|\n", 123456789);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Precision and width with no value
	printf_bytes = printf("|%10.5x|\n", 0);
	ft_printf_bytes = ft_printf("|%10.5x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: No width or precision, just value
	printf_bytes = printf("|%x|\n", 12345);
	ft_printf_bytes = ft_printf("|%x|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Uppercase %X, precision, and #
	printf_bytes = printf("|%#.10X|\n", 12345);
	ft_printf_bytes = ft_printf("|%#.10X|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Uppercase %X, width, zero padding
	printf_bytes = printf("|%08X|\n", 12345);
	ft_printf_bytes = ft_printf("|%08X|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Uppercase %X, left justification
	printf_bytes = printf("|%-8X|\n", 12345);
	ft_printf_bytes = ft_printf("|%-8X|\n", 12345);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Precision greater than the number of digits
	printf_bytes = printf("|%.10x|\n", 45);
	ft_printf_bytes = ft_printf("|%.10x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Precision equal to the number of digits
	printf_bytes = printf("|%.3x|\n", 45);
	ft_printf_bytes = ft_printf("|%.3x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Precision less than the number of digits
	printf_bytes = printf("|%.1x|\n", 45);
	ft_printf_bytes = ft_printf("|%.1x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width greater than the number of digits
	printf_bytes = printf("|%8x|\n", 45);
	ft_printf_bytes = ft_printf("|%8x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width greater than the number of digits and left-justified
	printf_bytes = printf("|%-8x|\n", 45);
	ft_printf_bytes = ft_printf("|%-8x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width and Precision together (left-justified)
	printf_bytes = printf("|%-8.5x|\n", 45);
	ft_printf_bytes = ft_printf("|%-8.5x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Width and Precision together (right-justified)
	printf_bytes = printf("|%8.5x|\n", 45);
	ft_printf_bytes = ft_printf("|%8.5x|\n", 45);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Zero value with precision zero
	printf_bytes = printf("|%.0x|\n", 0);
	ft_printf_bytes = ft_printf("|%.0x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Zero value with width greater than zero
	printf_bytes = printf("|%8x|\n", 0);
	ft_printf_bytes = ft_printf("|%8x|\n", 0);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Maximum width and precision with non-zero value
	printf_bytes = printf("|%20.15x|\n", 987654321);
	ft_printf_bytes = ft_printf("|%20.15x|\n", 987654321);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Multiple %x specifiers in a single format string
	printf_bytes = printf("|%8x|%10x|\n", 45, 255);
	ft_printf_bytes = ft_printf("|%8x|%10x|\n", 45, 255);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Multiple %x specifiers with left and right justification
	printf_bytes = printf("|%-8x|%8x|\n", 45, 255);
	ft_printf_bytes = ft_printf("|%-8x|%8x|\n", 45, 255);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Edge Case: Large number with precision and width
	printf_bytes = printf("|%10.8x|\n", 123456789);
	ft_printf_bytes = ft_printf("|%10.8x|\n", 123456789);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes printed by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m ***************** \033[0m           unsigned              \033[1;33m      ***************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	unsigned int large_number = 4294967295; // Maximum value for unsigned int
	// Test 1: Zero Value
	printf_bytes = printf("|%u| |%05u| |%-5u|\n", 0, 0, 0);
	ft_printf_bytes = ft_printf("|%u| |%05u| |%-5u|\n", 0, 0, 0);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 2: Large Positive Number
	printf_bytes = printf("|%u| |%20u| |%-20u|\n", large_number, large_number,
			large_number);
	ft_printf_bytes = ft_printf("|%u| |%20u| |%-20u|\n", large_number,
			large_number, large_number);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 3: Combination of Width and Precision
	printf_bytes = printf("|%10.5u| |%5.10u| |%-10.5u|\n", 123, 456, 789);
	ft_printf_bytes = ft_printf("|%10.5u| |%5.10u| |%-10.5u|\n", 123, 456, 789);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 5: Edge of Precision
	printf_bytes = printf("|%.u| |%.0u| |%.3u|\n", 0, 0, 42);
	ft_printf_bytes = ft_printf("|%.u| |%.0u| |%.3u|\n", 0, 0, 42);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 8: Width Less than Number of Digits
	printf_bytes = printf("|%3u| |%3.2u| |%-3u|\n", 1234, 5678, 90);
	ft_printf_bytes = ft_printf("|%3u| |%3.2u| |%-3u|\n", 1234, 5678, 90);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 9: Negative Values (Undefined Behavior)
	printf_bytes = printf("|%u| |%5u| |%05u|\n", -1, -42, -999);
	ft_printf_bytes = ft_printf("|%u| |%5u| |%05u|\n", -1, -42, -999);
	printf("Bytes printed by or_printf: %u\n", printf_bytes);
	printf("Bytes printed by ft_printf: %u\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	printf("\033[1;33m\n ************************************************************************** \n\033[0m");
	printf("\033[1;33m ************** \033[0m           string part               \033[1;33m      **************** \033[0m\n");
	printf("\033[1;33m ************************************************************************** \n\033[0m");
	str = "Hello";
	empty_str = "";
	null_str = NULL;
	// Test 1: Basic string with left justification
	printf_bytes = printf("|%-10s|\n", str);
	ft_printf_bytes = ft_printf("|%-10s|\n", str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 2: Basic string with right justification
	printf_bytes = printf("|%10s|\n", str);
	ft_printf_bytes = ft_printf("|%10s|\n", str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 3: String with precision less than length
	printf_bytes = printf("|%.3s|\n", str);
	ft_printf_bytes = ft_printf("|%.3s|\n", str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 4: String with precision greater than length
	printf_bytes = printf("|%.10s|\n", str);
	ft_printf_bytes = ft_printf("|%.10s|\n", str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 5: String with precision and width
	printf_bytes = printf("|%10.3s|\n", str);
	ft_printf_bytes = ft_printf("|%10.3s|\n", str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 6: Empty string with width
	printf_bytes = printf("|%10s|\n", empty_str);
	ft_printf_bytes = ft_printf("|%10s|\n", empty_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 7: Empty string with precision
	printf_bytes = printf("|%.3s|\n", empty_str);
	ft_printf_bytes = ft_printf("|%.3s|\n", empty_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 8: NULL string with default behavior
	printf_bytes = printf("|%s|\n", null_str);
	ft_printf_bytes = ft_printf("|%s|\n", null_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 9: NULL string with width
	printf_bytes = printf("|%10s|\n", null_str);
	ft_printf_bytes = ft_printf("|%10s|\n", null_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 10: NULL string with precision
	printf_bytes = printf("|%.3s|\n", null_str);
	ft_printf_bytes = ft_printf("|%.3s|\n", null_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");
	printf("\n");
	// Test 11: NULL string with precision and width
	printf_bytes = printf("|%10.3s|\n", null_str);
	ft_printf_bytes = ft_printf("|%10.3s|\n", null_str);
	printf("Bytes printed by or_printf: %d\n", printf_bytes);
	printf("Bytes prin by ft_printf: %d\n", ft_printf_bytes);
	if (printf_bytes == ft_printf_bytes)
	{
		printf("\033[32m ************* OK *************  \033[0m\n");
		count++;
	}
	else
		printf("\033[31m ************* NO *************  \033[0m\n");

    if (count == 109)
    {   
        printf("\033[35m********************************************* \033[0m\n");
        printf("\033[32m******** All tests output and bytes OK! *******  \033[0m\n");   
        printf("\033[35m***********************************************  \033[0m\n");
    }
    else
    {   
        printf("\033[31m************************************  \033[0m\n");
        printf("\033[31m*********** ERRORS FOUND ***********  \033[0m\n");   
        printf("\033[31m************************************  \033[0m\n");
    }


	return (0);
}

"""

# ==============================================================================
# RUNNER LOGIC
# ==============================================================================
def execute_shell_command(command_arguments, execution_directory=None, execution_timeout=15, input_data=None):
    """
    Runs shell commands safely using binary mode to capture raw output.
    """
    encoded_input = None
    if input_data is not None:
        encoded_input = input_data.encode('utf-8', errors='ignore') if isinstance(input_data, str) else input_data

    try:
        completed_process = subprocess.run(
            command_arguments,
            cwd=execution_directory,
            input=encoded_input,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=execution_timeout
        )

        decoded_stdout = completed_process.stdout.decode('utf-8', errors='replace')
        decoded_stderr = completed_process.stderr.decode('utf-8', errors='replace')
        
        return subprocess.CompletedProcess(
            args=command_arguments,
            returncode=completed_process.returncode,
            stdout=decoded_stdout,
            stderr=decoded_stderr
        )
        
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(
            args=command_arguments,
            returncode=-1,
            stdout="",
            stderr="Execution timed out (potential infinite loop)"
        )


def run_make_rule(project_directory: Path, rule: str = "") -> bool:
    """Invokes make on the project directory with the specified rule."""
    command = ["make"]
    if rule:
        command.append(rule)
        
    print(f"{COLOR_INFO}Running: {' '.join(command)} in {project_directory}...{COLOR_RESET}")
    result = execute_shell_command(command, execution_directory=project_directory)
    
    if result.returncode != 0:
        print(f"{COLOR_FAILURE}Make failed!{COLOR_RESET}")
        print(result.stderr)
        return False
    return True


def compile_mandatory(build_directory: Path, project_directory: Path) -> Path:
    """Compiles the mandatory test runner."""
    main_c_path = build_directory / "main.c"
    main_c_path.write_text(C_MANDATORY_RUNNER_TEMPLATE, encoding="utf-8")
    
    output_binary = build_directory / "test_mandatory"
    library_path = project_directory / "libftprintf.a"
    
    if not library_path.exists():
        raise FileNotFoundError(f"Could not find library at: {library_path}")

    compilation_command = [
        "cc",
        "-Wall",
        "-Wextra",
        "-Werror",
        "-g",
        "-I", str(project_directory),
        str(main_c_path),
        str(library_path),
        "-o", str(output_binary)
    ]
    
    result = execute_shell_command(compilation_command)
    if result.returncode != 0:
        raise RuntimeError(f"Compilation failed:\n{result.stderr.strip()}")
    return output_binary


def compile_bonus(build_directory: Path, project_directory: Path) -> Path:
    """Compiles the bonus test runner."""
    main_bonus_c_path = build_directory / "main_bonus.c"
    main_bonus_c_path.write_text(C_BONUS_RUNNER_TEMPLATE, encoding="utf-8")
    
    output_binary = build_directory / "test_bonus"
    library_path = project_directory / "libftprintf.a"
    
    if not library_path.exists():
        raise FileNotFoundError(f"Could not find library at: {library_path}")

    compilation_command = [
        "cc",
        "-Wall",
        "-Wextra",
        "-Werror",
        "-g",
        "-I", str(project_directory),
        str(main_bonus_c_path),
        str(library_path),
        "-o", str(output_binary)
    ]
    
    result = execute_shell_command(compilation_command)
    if result.returncode != 0:
        raise RuntimeError(f"Compilation failed:\n{result.stderr.strip()}")
    return output_binary


def parse_valgrind_leaks(valgrind_output: str) -> bool:
    """
    Parses Valgrind's output to check if any memory was leaked or if there were access errors.
    Returns True if leaks/errors were detected, False if clean.
    """
    has_leak = False
    

    if "definitely lost: 0 bytes in 0 blocks" not in valgrind_output and "definitely lost:" in valgrind_output:
        has_leak = True
    if "indirectly lost: 0 bytes in 0 blocks" not in valgrind_output and "indirectly lost:" in valgrind_output:
        has_leak = True
        

    if "ERROR SUMMARY: 0 errors from 0 contexts" not in valgrind_output and "ERROR SUMMARY:" in valgrind_output:
        has_leak = True
        
    return has_leak


def main():
    script_directory = Path(__file__).resolve().parent
    project_directory = script_directory.parent 
    
    print(f"{COLOR_INFO}Target Project Directory: {project_directory}{COLOR_RESET}")

    print(f"{COLOR_CYAN}┌──────────────────────────────────────────────┐{COLOR_RESET}")
    print(f"{COLOR_CYAN}│ ******  tdaniel-'s ft_printf tester  ******* │{COLOR_RESET}")
    print(f"{COLOR_CYAN}│                                              │{COLOR_RESET}")
    print(f"{COLOR_CYAN}│  Select Test Mode:                           │{COLOR_RESET}")
    print(f"{COLOR_CYAN}├──────────────────────────────────────────────┤{COLOR_RESET}")
    print(f"│  {COLOR_YELLOW}[1]{COLOR_RESET} Mandatory Part                          │")
    print(f"│  {COLOR_YELLOW}[2]{COLOR_RESET} Bonus Part                              │")
    print(f"{COLOR_CYAN}└──────────────────────────────────────────────┘{COLOR_RESET}")

    user_choice = input(f"{COLOR_CYAN}👉 Enter choice (1 or 2): {COLOR_RESET}").strip()
    print()
    
    if user_choice not in ["1", "2"]:
        print(f"{COLOR_FAILURE}Invalid selection. Exiting.{COLOR_RESET}")
        return 1

    with tempfile.TemporaryDirectory() as temp_dir_str:
        temp_dir = Path(temp_dir_str)
        
        if user_choice == "1":
            if not run_make_rule(project_directory, rule=""):
                return 1
            try:
                test_binary = compile_mandatory(temp_dir, project_directory)
            except Exception as error:
                print(f"{COLOR_FAILURE}Compilation Error:{COLOR_RESET}\n{error}")
                return 1
        else:
            if not run_make_rule(project_directory, rule="bonus"):
                return 1
            try:
                test_binary = compile_bonus(temp_dir, project_directory)
            except Exception as error:
                print(f"{COLOR_FAILURE}Compilation Error:{COLOR_RESET}\n{error}")
                return 1

        print(f"{COLOR_INFO}Executing Test Program with Valgrind...{COLOR_RESET}")
        valgrind_command = [
            "valgrind",
            "--leak-check=full",
            "--show-leak-kinds=all",
            str(test_binary)
        ]
        
        execution_result = execute_shell_command(valgrind_command, execution_directory=project_directory)
        
        if execution_result.returncode != 0 and execution_result.returncode < 0:
            signal_num = abs(execution_result.returncode)
            print(f"{COLOR_FAILURE}Execution crashed! Process killed by signal {signal_num} (e.g. Segfault/Timeout).{COLOR_RESET}")
            if execution_result.stderr:
                print(f"Error output:\n{execution_result.stderr}")
            return 1


        print(f"{COLOR_INFO}------- TESTER OUTPUT -------{COLOR_RESET}")
        print(execution_result.stdout)
        print(f"{COLOR_INFO}----------------------------------------------{COLOR_RESET}")
        print(f"{COLOR_INFO}------------ VALGRIND MEMORY REPORT ------------{COLOR_RESET}")
        print(execution_result.stderr)
        
        print(f"{COLOR_INFO}----------------------------------------------{COLOR_RESET}")
        

        if parse_valgrind_leaks(execution_result.stderr):
            print(f"{COLOR_FAILURE}❌ TEST RUN FINISHED: Memory leaks or memory errors were detected! Check the report above.{COLOR_RESET}")
        else:
            print(f"{COLOR_SUCCESS}✔ TEST RUN FINISHED: All heap blocks were freed successfully! No leaks detected.{COLOR_RESET}")
        print(f"{COLOR_INFO}----------------------------------------------{COLOR_RESET}")
    return 0


if __name__ == "__main__":
    sys.exit(main())