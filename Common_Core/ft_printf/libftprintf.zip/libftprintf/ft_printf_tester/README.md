# ft_printf tester

An interactive Python testing suite designed to validate your `ft_printf` project.  

The script automatically builds your library using your project's `Makefile`, compares printed strings and byte counts against the original standard `printf` (referred to as `or_printf` in the tests), and uses **Valgrind** to verify that your implementation is 100% memory-leak-free.

Many of the bonus-part edge cases and weird behaviours are also tested, even though they may not be checked my Moulinette.

---

## Features

* **Interactive CLI Interface:** A command-line menu that lets you choose between testing the **Mandatory Part** or the **Bonus Part** instantly.
* **Makefile Integration:** Automatically compiles your C library on-the-fly by running your project's local `Makefile` commands.
* **Strict Byte & Output Matching:** Prints tests side-by-side to ensure both the stdout text and returned bytes printed match the standard C library down to the char.
* **Built-in Valgrind Analyzer:** Automatically wraps the test binaries with Valgrind to monitor heap allocations, ensuring "0 bytes in 0 blocks" at exit and 0 total leak errors.
* **Dynamic Sandboxing:** Generates temp source files and binaries in `/tmp/`, leaving your project folder completely clean of junk compilation artifacts.

<div align="center">
    <br>
    <a href="https://github.com/tdanielsousa/42_School/blob/main/Subjects/ft_printf_subject.pdf" target="_blank">
        <img src="https://img.shields.io/badge/View%20Subject-PDF-red?style=for-the-badge&logo=adobe-acrobat-reader&logoColor=white" alt="Subject PDF" height="40">
    </a>
    <p><i>Click on the button above to see the subject's pdf.</i></p>
    <br>
</div>

---

## Getting Started

### 1. File Placement
The tester script should reside in a folder (such as `ft_printf_tester/`) inside your parent `ft_printf` project directory:

    ~/GIT/CommonCore/Milestone1/ft_printf/
    ├── ft_printf.c
    ├── ft_printf.h
    ├── Makefile
    └── ft_printf_tester/
        └── ft_printf_tester.py

### 2. Run the Tester
Navigate to the tester folder and run it using Python:

    cd ft_printf_tester
    python ft_printf_tester.py

Then you need to select either `1` for mandatory tests, or `2` for the bonus part tests.

---

## Testing Coverage

### Standard version
The script tests all key conversions:
* **%c:** Single characters, including boundary values.
* **%s:** Standard strings, empty strings, and pointer string structures.
* **%p:** Memory pointer addresses and `(nil)` output.
* **%d / %i:** Standard signed numbers, including negative boundaries.
* **%u:** Large unsigned decimal integers (e.g., `4294967295`).
* **%x / %X:** Lowercase and uppercase hexadecimal translations.
* **%%:** Escaped percentage outputs.

### Bonus Flag System
Under option `[2] Bonus Part`, the tester rigorously evaluates your flag formatting parser, checking:
* **Width & Precision:** Any combination of the `'-0.'` flags alongside a minimum field width across **all** conversions.
* **Special Modifiers:** Complete verification of the `'# +'` flags (including the space flag `' '`) on relevant specifiers to ensure proper padding, sign representation, and hex formatting.

---
